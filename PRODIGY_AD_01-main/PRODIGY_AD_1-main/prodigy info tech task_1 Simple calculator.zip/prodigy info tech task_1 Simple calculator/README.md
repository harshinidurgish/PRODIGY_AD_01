Prodigy Info Tech task-1 of the Android development
git repository link :-
Linkedin overview link :-